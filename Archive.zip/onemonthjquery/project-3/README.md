# Project 3: Todo List

Simple todo list app, using local storage to persist data.

## Links

jQuery: http://jquery.com/

localStorage: http://www.w3schools.com/html/html5_webstorage.asp

## Challenge
* Create a custom animation using `animate()`
* Add a 4th question to the FAQ
* Replace the text of one of the answers with an image or gif
