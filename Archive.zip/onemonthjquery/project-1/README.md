# Project 1: Lightbox

Simple photo gallery app, using the Lightbox library.

## Links

jQuery: http://jquery.com/

Lightbox: http://lokeshdhakar.com/projects/lightbox2/

## Challenge

* Choose 6 photos from Google (or your personal library) and replace the current images in your project
* Replace the header text to something relevant to your new photos
* Add one more option that Lightbox provides
