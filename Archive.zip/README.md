aREST-app-example
=================

Example for the aREST Arduino library using HTML, JavaScript and PHP
